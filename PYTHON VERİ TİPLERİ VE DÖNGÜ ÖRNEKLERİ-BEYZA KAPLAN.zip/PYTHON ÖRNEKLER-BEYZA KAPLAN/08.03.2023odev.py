## String Vei Tipi r##
stringDegisken = "Beyza KAPLAN"
ayrac = "*******************"
## Numerik/Sayısal Veri Tipi ##
intDegisken = 36520
floatDegisken = 142.58
complexDegisken = 55j
## Sıralama Veri Tipi ##
listDegisken = ["Liste", "Değişkenine", "Örnek", 183006025]
tupleDegisken = ("Sadece", "Okunabilir", "Bir veri tipidir.")
## Haritalama Veri Tipi ##
dictDegisken = {}
dictDegisken ['kayitNo'] = 12354568
dictDegisken ['unvan'] = "Stajyer"
## Değişken Türlerini Kontrol Ederek Ekrana Yazdıralım ##
print("\nPython Veri Tipleri İçin Örnekler\n")
print("\nString Veri Tipi\n"+ayrac)
print(stringDegisken)
print("\nNumerik/Sayısal Veri Tipi\n"+ayrac)
print(intDegisken)
print(floatDegisken)
print(complexDegisken)
print("\nSıralama Veri Tipi\n"+ayrac)
print(listDegisken)
print(tupleDegisken)
print("\nHaritalama Veri Tipi\n"+ayrac)
print(dictDegisken)