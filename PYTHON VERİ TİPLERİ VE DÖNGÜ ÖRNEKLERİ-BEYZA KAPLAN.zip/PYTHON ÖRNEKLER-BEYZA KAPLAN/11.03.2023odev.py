kayitdefteri =["Kişi1","Kişi3","Kişi4"]
print(kayitdefteri)

#Listenin sonuna Eleman Ekleme;
kayitdefteri.append("Kişi5")
print(kayitdefteri)

#Listenin istenen sıradaki verinin yerine Elaman ekleme;
kayitdefteri.insert(1,"Kişi2")
print(kayitdefteri)

#Listeden Elaman Silme;
kayitdefteri.remove("Kişi1")
print(kayitdefteri)

#Listedeki kişileri ekrana yazdırma;
for liste in kayitdefteri:
    print(liste)

#listeye Birden fazla Eleman ekleme;
isimler=[]
for i in range(4):
  isimler.append(input("Bir isim girin:"))
  
#listedeki değerleri yazdırma
for isim in isimler:
  print(isim)

#Listede Birden fazla elemanı aynı anda Silme İşlemi;
ogrenciler=input("Kaç Adet Kayıt Silmek istiyorsunuz ? : ")
i=0
while i<int(ogrenciler):
    kayitdefteri.remove(kayitdefteri[i])
    i+=1
print(kayitdefteri)

